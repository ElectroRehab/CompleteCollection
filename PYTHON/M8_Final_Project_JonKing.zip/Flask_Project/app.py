# In this assignment you will demonstrate your understanding of using Flask to 
# build Web Applications.
#
# First you are to Create a virtual environment and install Flask in the 
# environment and then Choose ONE of the two options below (10 points for 
# virtual environment)
#
# 1. Create a web site that contains a minimum of 3 pages.
#
# Make sure you have a navigation bar with links to the different pages on your
# site. The navigation bar should be added to ALL pages and MUST be functional
# (70 points)
#
# At least one of your pages has to have an image or two. (20 points)
#
#
# Note: Don't worry too much about the content, choose a topic of your choice 
#       and keep it simple. The goal here to demonstrate your understanding of 
#       using Flask to create website. Use the provided recordings and 
#       resources
#
#
#
# 2. Convert one of the programs you did for this class to a web Application.
#
# Again, keep this simple. The program has to contain more than just two entry 
# fields. If you can't think of anything, consider the option below
#
# An application that determines students’ grade, sum of grades and average. 
# The application is to contain the following:
#   A) A field for student name
#   B) A field for student score
#   C) A button to add another score (if user wants)
#   D) A button to calculate sum and average
# Once the information is entered and the “Calculate” button is clicked, 
# display the results as following:
# Name: student name
#
# Sum of Grades: whatever the sum is
#
# Average:   whatever the average is
#
# Note: Again, if you choose to convert a different program, you can. Just 
# keep it simple, don’t stress over it.
#
# Use the provided recordings and resources you created a web application in 
# M7HW_Flask, use that as a guide. Once you’ve completed the project, 
# zip/compress the project folder and turn it in via this link.
#
# A brief description of the project (SHOWN ABOVE ^^^)
# Jon King
# 10MAY20
# CSC221 M8Final Project

from flask import Flask, render_template, url_for

app = Flask(__name__)

@app.route('/')

def index():
    return render_template("index.html")

@app.route('/page2')

def page2():
    return render_template("page2.html")

@app.route('/page3')

def page3():
    return render_template("page3.html")

if __name__ == "__main__":
    app.run()
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    