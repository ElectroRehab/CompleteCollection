#include "Artist.h"

// TODO: Define default constructor

// TODO: Define second constructor to initialize
//       private fields (title, yearCreated, artist)

// TODO: Define get functions: GetTitle(), GetYearCreated()

// TODO: Define PrintInfo() function