#include "Artist.h"
#include <iostream>
#include <string>
using namespace std;

// TODO: Define default constructor

// TODO: Define second constructor to initialize
//       private fields (artistName, birthYear, deathYear)

// TODO: Define get functions: GetName(), GetBirthYear(), GetDeathYear()

// TODO: Define PrintInfo() function
//      If deathYear is entered as -1, only print birthYear